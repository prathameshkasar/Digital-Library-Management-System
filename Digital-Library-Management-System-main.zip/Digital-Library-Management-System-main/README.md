# Digital-Library-Management-System
The Library Management system undertaken as a project is based on rele- vant technologies, which is an attempt to automate the existing library.
# New Features!
- The project enables its admin to perform all the operations regarding a library.
- The project enables the admin to make entry of a new book, deleting the record of a book from the library, issuing a book to member, making entry of a new member, deleting the record of a member from the library etc.
- The process model we have used for our project is Linear Sequential because the requirements are well stated and understood before in hand. 
- In analysis phase we analysed the requirements of what the project will do. 
- We collected the requirements needed to develop the project. 
- Then in the design phase we designed our project according to user satisfaction. 
- We created database to store the details of members, books in tables. 
- We designed System diagrams based upon the operations that was carrying in the project. 
- Then cost and effort estimations are calculated and testing and coding processes have been carried out.
- Hence inthe existingsystem for LIBRARY MANAGEMENT SYSTEM, the performance evaluation system and the maintenance are done manually. 
- The proposed system will maintain all the information in a standard database and

# Portal-GUI
**1. Homepage**
![Screenshot (36)](https://user-images.githubusercontent.com/89139455/222629623-68cba7a5-9faf-4877-9429-5444377bb805.png)
**2. Admin Login Page**
![Screenshot (37)](https://user-images.githubusercontent.com/89139455/222629659-37ae767c-1da6-4694-83ca-5165aa8e31d2.png)
![Screenshot (27)](https://user-images.githubusercontent.com/89139455/222629670-6784f414-7848-4cfb-975e-7b02fee29dd7.png)
![Screenshot (21)](https://user-images.githubusercontent.com/89139455/222629726-8d874165-56e5-438e-8f0c-9c727a91ab36.png)
![Screenshot (22)](https://user-images.githubusercontent.com/89139455/222629766-726e3eb4-701d-4360-8773-74932d468f35.png)
![Screenshot (23)](https://user-images.githubusercontent.com/89139455/222629783-df2061e4-016b-4033-97de-c2e86ffba5a5.png)
![Screenshot (24)](https://user-images.githubusercontent.com/89139455/222629789-1b647899-4507-4c88-a3bf-b44555b5f830.png)
![Screenshot (28)](https://user-images.githubusercontent.com/89139455/222629849-a3c5684e-efc9-47cf-a162-0d99608e8572.png)
![Screenshot (29)](https://user-images.githubusercontent.com/89139455/222629856-d5af2cb6-f0ba-4db0-90c9-7c9f58cf0216.png)
![Screenshot (34)](https://user-images.githubusercontent.com/89139455/222629925-909a3517-ebc0-4a20-9be3-246622374b7c.png)
![Screenshot (35)](https://user-images.githubusercontent.com/89139455/222629934-19d8e47c-f50b-4a56-b2ef-035ec04c60c9.png)
